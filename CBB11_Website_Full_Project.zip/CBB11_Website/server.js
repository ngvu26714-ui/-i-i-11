try { require("dotenv").config(); } catch (_) {}

const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const DATA = path.join(ROOT, "data");
const UPLOADS = path.join(ROOT, "uploads");
for (const dir of [DATA, UPLOADS, path.join(ROOT, "sessions")]) {
  fs.mkdirSync(dir, { recursive: true });
}
const db = new Database(path.join(DATA, "cbb11.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'admin'
);
CREATE TABLE IF NOT EXISTS posts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'Tin đơn vị',
  content TEXT NOT NULL,
  author TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS documents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  filename TEXT NOT NULL,
  original_name TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS scores (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  squad TEXT NOT NULL,
  content TEXT NOT NULL,
  points INTEGER NOT NULL DEFAULT 0,
  note TEXT DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
`);
const adminName = process.env.ADMIN_USERNAME || "admin";
const adminPass = process.env.ADMIN_PASSWORD || "CBB11@2026";
if (!db.prepare("SELECT id FROM users WHERE username=?").get(adminName)) {
  db.prepare("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)")
    .run(adminName, bcrypt.hashSync(adminPass, 12), "admin");
  console.log(`Tai khoan quan tri mac dinh: ${adminName}`);
  if (!process.env.ADMIN_PASSWORD) console.log("Mat khau mac dinh: CBB11@2026 - hay doi ngay sau khi dang nhap.");
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(session({
  store: new SQLiteStore({ db: "sessions.sqlite", dir: path.join(ROOT, "sessions") }),
  secret: process.env.SESSION_SECRET || "development-secret-change-this-before-deploy",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 8 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(ROOT, "public")));

function adminOnly(req, res, next) {
  if (req.session.user?.role !== "admin") return res.status(401).json({ error: "Vui long dang nhap quan tri." });
  next();
}
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOADS),
  filename: (_req, file, cb) => {
    const safe = path.basename(file.originalname).replace(/[^a-zA-Z0-9._-]/g, "_");
    cb(null, `${Date.now()}-${safe}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 15 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ok = /\.(pdf|doc|docx|ppt|pptx|xls|xlsx|jpg|jpeg|png)$/i.test(file.originalname);
    cb(ok ? null : new Error("Chi chap nhan PDF, Office va anh."), ok);
  }
});

app.get("/api/me", (req, res) => res.json({ user: req.session.user || null }));
app.post("/api/login", (req, res) => {
  const { username, password } = req.body || {};
  const user = db.prepare("SELECT * FROM users WHERE username=?").get(String(username || ""));
  if (!user || !bcrypt.compareSync(String(password || ""), user.password_hash)) {
    return res.status(401).json({ error: "Ten dang nhap hoac mat khau khong dung." });
  }
  req.session.user = { id: user.id, username: user.username, role: user.role };
  res.json({ ok: true, user: req.session.user });
});
app.post("/api/logout", (req, res) => req.session.destroy(() => res.json({ ok: true })));

app.get("/api/posts", (_req, res) => {
  res.json(db.prepare("SELECT * FROM posts ORDER BY id DESC LIMIT 100").all());
});
app.post("/api/posts", adminOnly, (req, res) => {
  const { title, category, content, author } = req.body || {};
  if (!title?.trim() || !content?.trim()) return res.status(400).json({ error: "Can nhap tieu de va noi dung." });
  const info = db.prepare("INSERT INTO posts(title,category,content,author) VALUES(?,?,?,?)")
    .run(title.trim(), String(category || "Tin don vi"), content.trim(), String(author || req.session.user.username).trim());
  res.json({ ok: true, id: info.lastInsertRowid });
});
app.delete("/api/posts/:id", adminOnly, (req, res) => {
  db.prepare("DELETE FROM posts WHERE id=?").run(Number(req.params.id));
  res.json({ ok: true });
});

app.get("/api/documents", (_req, res) => {
  res.json(db.prepare("SELECT id,title,original_name,created_at FROM documents ORDER BY id DESC").all());
});
app.post("/api/documents", adminOnly, upload.single("file"), (req, res) => {
  if (!req.file || !req.body.title?.trim()) return res.status(400).json({ error: "Nhap ten tai lieu va chon tep." });
  const info = db.prepare("INSERT INTO documents(title,filename,original_name) VALUES(?,?,?)")
    .run(req.body.title.trim(), req.file.filename, req.file.originalname);
  res.json({ ok: true, id: info.lastInsertRowid });
});
app.get("/api/documents/:id/download", (req, res) => {
  const doc = db.prepare("SELECT * FROM documents WHERE id=?").get(Number(req.params.id));
  if (!doc) return res.status(404).send("Khong tim thay tai lieu.");
  res.download(path.join(UPLOADS, doc.filename), doc.original_name);
});
app.delete("/api/documents/:id", adminOnly, (req, res) => {
  const doc = db.prepare("SELECT * FROM documents WHERE id=?").get(Number(req.params.id));
  if (doc) {
    const p = path.join(UPLOADS, doc.filename);
    if (fs.existsSync(p)) fs.unlinkSync(p);
    db.prepare("DELETE FROM documents WHERE id=?").run(doc.id);
  }
  res.json({ ok: true });
});

app.get("/api/scores", (_req, res) => res.json(db.prepare("SELECT * FROM scores ORDER BY squad, id").all()));
app.post("/api/scores", adminOnly, (req, res) => {
  const { squad, content, points, note } = req.body || {};
  if (!squad?.trim() || !content?.trim() || !Number.isInteger(Number(points))) {
    return res.status(400).json({ error: "Kiem tra lai thong tin diem thi dua." });
  }
  db.prepare("INSERT INTO scores(squad,content,points,note) VALUES(?,?,?,?)")
    .run(squad.trim(), content.trim(), Math.max(0, Math.min(100, Number(points))), String(note || ""));
  res.json({ ok: true });
});
app.delete("/api/scores/:id", adminOnly, (req, res) => {
  db.prepare("DELETE FROM scores WHERE id=?").run(Number(req.params.id));
  res.json({ ok: true });
});

app.use((err, _req, res, _next) => {
  console.error(err.message);
  res.status(400).json({ error: err.message || "Co loi xay ra." });
});
app.listen(PORT, () => console.log(`CBB11 dang chay tai http://localhost:${PORT}`));

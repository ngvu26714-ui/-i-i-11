# Website CBB11 – Đại đội 11

## 1. Cài đặt
- Cài Node.js bản LTS từ https://nodejs.org/
- Giải nén thư mục này.
- Mở thư mục bằng Visual Studio Code.
- Mở Terminal trong VS Code và chạy:

```bash
npm install
```

## 2. Chạy website

```bash
npm start
```

Mở trình duyệt tại: http://localhost:3000

## 3. Đăng nhập quản trị lần đầu
- Tên đăng nhập: `admin`
- Mật khẩu mặc định: `CBB11@2026`

**Đổi mật khẩu trước khi đưa website lên mạng.** Có thể đặt biến môi trường `ADMIN_USERNAME`, `ADMIN_PASSWORD` và `SESSION_SECRET`. Tạo file `.env` từ `.env.example`; để dùng file `.env`, cài thêm `dotenv` bằng `npm install dotenv`.

## 4. Chức năng
- Tin tức: quản trị viên đăng/xóa bài; mọi người xem.
- Tài liệu: quản trị viên tải lên/xóa; mọi người tải xuống.
- Thi đua: quản trị viên cập nhật điểm; mọi người xem.
- Dữ liệu lưu trong SQLite ở thư mục `data`; tệp tải lên nằm trong `uploads`.

## 5. Lưu ý triển khai
Để nhiều máy cùng truy cập, cần triển khai Node.js trên máy chủ nội bộ hoặc dịch vụ hosting có hỗ trợ Node.js và lưu trữ bền vững. Không mở cổng trực tiếp ra Internet nếu chưa cấu hình HTTPS, mật khẩu mạnh, sao lưu và phân quyền phù hợp. Đây là bộ khung khởi đầu; cần kiểm thử và điều chỉnh theo quy định bảo mật của đơn vị.
